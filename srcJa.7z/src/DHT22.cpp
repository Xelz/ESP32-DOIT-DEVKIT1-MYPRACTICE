// #include "DHT22.h"
// // #include "Display.h"

// uint8_t data[5];
// #define DHT_PIN 16   


// bool readDHT22() {
//   memset(data, 0, 5);

//   // Step 1: MCU sends start signal
//   pinMode(DHT_PIN, OUTPUT);
//   digitalWrite(DHT_PIN, LOW);
//   delay(1);   // 18 ms LOW
//   digitalWrite(DHT_PIN, HIGH);
//   delayMicroseconds(20);
//   pinMode(DHT_PIN, INPUT);

//   // Step 2: Sensor response
//   unsigned long t = micros();
//   while (digitalRead(DHT_PIN) == HIGH) {
//     if (micros() - t > 90) {
//       Serial.println("No response LOW");
//       return false;
//     }
//   }
//   while (digitalRead(DHT_PIN) == LOW);   // 80 µs LOW
//   while (digitalRead(DHT_PIN) == HIGH);  // 80 µs HIGH

//   // Step 3: Read 40 bits
//   for (int i = 0; i < 40; i++) {
//     while (digitalRead(DHT_PIN) == LOW);  // wait for start of bit

//     unsigned long start = micros();
//     while (digitalRead(DHT_PIN) == HIGH);
//     unsigned long duration = micros() - start;

//     int byteIndex = i / 8;
//     data[byteIndex] <<= 1;
//     if (duration > 28) { // >28 µs = logic 1
//       data[byteIndex] |= 1;
//     }
//   }

//   // Step 4: Checksum
//   if ((uint8_t)(data[0] + data[1] + data[2] + data[3]) != data[4]) {
    
//     Serial.println("Checksum error");
//     return false;
//   }


//   Serial.print("Raw HEX: ");
//   for (int i = 0; i < 5; i++) {
//     Serial.print("0x");
//     Serial.print(data[i], HEX);
//     Serial.print(" ");
//   }
//   Serial.println();
//   Serial.print("Humidity: ");
//   Serial.print(float(data[0] << 8 | data[1])*0.10);
//   Serial.print("\t");
//   Serial.print("Temperature: ");
//   Serial.print(float(data[2] << 8 | data[3])*0.10);
//   Serial.print(" ");
//   Serial.print("Checksum: ");
//   Serial.print(data[4], DEC);
//   Serial.println(" ");
//   Serial.println(" ");
//   return true;
// }

// void getHumidityTemperature(float* humidity, float* temperature) {
//   if (readDHT22()) {
//     *humidity = float(data[0] << 8 | data[1]) * 0.10;
//     *temperature = float(data[2] << 8 | data[3]) * 0.10;
//   } else {
//     *humidity = -1.0; // Indicate error
//     *temperature = -1.0; // Indicate error
//   }
// }

#include "DHT22.h"

DHT22::DHT22(uint8_t pin) : pin(pin), humidity(0.0), temperature(0.0) {
    memset(data, 0, sizeof(data));
}

bool DHT22::readDHT22() {
    memset(data, 0, sizeof(data));

    // Step 1: MCU sends start signal
    pinMode(pin, OUTPUT);
    digitalWrite(pin, LOW);
    delay(1);   // 18 ms LOW
    digitalWrite(pin, HIGH);
    delayMicroseconds(20);
    pinMode(pin, INPUT);

    // Step 2: Sensor response
    unsigned long t = micros();
    while (digitalRead(pin) == HIGH) {
        if (micros() - t > 90) {
            Serial.println("No response LOW");
            return false;
        }
    }
    while (digitalRead(pin) == LOW);   // 80 µs LOW
    while (digitalRead(pin) == HIGH);  // 80 µs HIGH

    // Step 3: Read 40 bits
    for (int i = 0; i < 40; i++) {
        while (digitalRead(pin) == LOW);  // wait for start of bit

        unsigned long start = micros();
        while (digitalRead(pin) == HIGH);
        unsigned long duration = micros() - start;

        int byteIndex = i / 8;
        data[byteIndex] <<= 1;
        if (duration > 28) { // >28 µs = logic 1
            data[byteIndex] |= 1;
        }
    }

    // Step 4: Checksum
    if ((uint8_t)(data[0] + data[1] + data[2] + data[3]) != data[4]) {
        Serial.println("Checksum error");
        return false;
    }

    humidity = float(data[0] << 8 | data[1]) * 0.10;
    temperature = float(data[2] << 8 | data[3]) * 0.10;

    return true;
}

float DHT22::getHumidity() const{
    return humidity;
}

float DHT22::getTemperature() const{
    return temperature;
}